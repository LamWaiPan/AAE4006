# % Building up an aircraft model

