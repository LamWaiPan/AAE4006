# AAE4006
This is the GitHub repository for the subject AAE4006.

You will find all the source codes for tasks here. 

When you submit your work, just upload the solutions in your group repository. Our TA will open your page and grade the work in due course.


## 2022.03.13
Task 6 has been updated
## 2022.03.07
Task 6 has been released, and this will be the last task
## 2022.02.22
Task 4 compatible with MATLAB older version has been updated
## 2022.02.20
Task 5 has been released
## 2022.02.14
Task 4 has been released
## 2022.02.08
Task 3 has been released
## 2022.01.17
Task 2 "Coordinate_Systems_LV.slx" has been updated
## 2022.01.16
Task 2 has been released
## 2022.01.10
Task 1 has been released


